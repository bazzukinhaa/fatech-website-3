# Formulário

> Criei este formulário bem desafiador. Consegui criar do zero e deixar igual ao que foi pedido.
<br/>

> Em breve todos os meus projetos vai está responsivo.

<br/>

[link da página](https://romeusorionaet.github.io/CriandoFormulario/)

<br/>

![preview](./preview/preview.png)

## Tecnologias

- HTML
- CSS